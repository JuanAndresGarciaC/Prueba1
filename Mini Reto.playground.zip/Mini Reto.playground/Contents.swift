//: Playground - noun: a place where people can play

import UIKit

var resultadoFinal = ""

let numeros = 0...100

for var todos = 0; todos < numeros.count; todos++ {
    resultadoFinal = "\(todos)"
    if todos % 5 == 0{
     resultadoFinal = "\(resultadoFinal) Bingo!!!"
    }
    
    if todos % 2 == 0{
     resultadoFinal = "\(resultadoFinal) par!!!"
    }else{
     resultadoFinal = ("\(resultadoFinal) impar!!!")
    }
    
    if todos > 30 && todos < 40 {
     resultadoFinal = ("\(resultadoFinal) Viva Swift!!!")
    }
    print(resultadoFinal)
}
